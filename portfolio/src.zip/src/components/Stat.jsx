import GitHubCalendar from 'react-github-calendar';
import "./style/Stat.scss"

const Stat=()=>{
    return(
        <div className='calender'>
            <GitHubCalendar username="Ayushi0516"  />
       </div>

    )
}
export default Stat